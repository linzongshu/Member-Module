CREATE TABLE `{userinfo}` (
  `id`       INT(10) UNSIGNED         NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(32)              NOT NULL DEFAULT '',
  `password` VARCHAR(255)             NOT NULL DEFAULT '',
  `gender`   ENUM('m', 'f')           NOT NULL DEFAULT 'm',
  `email`    VARCHAR(255)             NOT NULL DEFAULT '',
  `country`  VARCHAR(32)              NOT NULL DEFAULT 'CHN',
  `message`  TEXT                     DEFAULT NULL,
  `photo`    VARCHAR(255)             DEFAULT NULL,

  PRIMARY KEY  (`id`),
  UNIQUE KEY   (`username`),
  UNIQUE KEY   (`email`),
  KEY          (`gender`),
  KEY          (`country`)
);