<?php
namespace Module\Account\Form;

use Pi;
use Zend\InputFilter\InputFilter;
use Zend\Validator\StringLength;

class LoginFilter extends InputFilter
{
    public function __construct()
    {
        $this->add(array(
            'name'        => 'username',
            'required'    => true,
            'filters'     => array(
                array(
                    'name'     => 'StringTrim',
                ),
            ),
            'validators'  => array(
                array(
                    'name'     => 'Regex',
                    'options'  => array(
                        'pattern'   => '/^[a-zA-Z0-9][a-zA-Z0-9-_]{3,24}$/',
                    ), 
                ),
            ),
        ));
        
        $this->add(array(
            'name'        => 'password',
            'required'    => true,
            'filters'     => array(
                array(
                    'name'     => 'StringTrim',
                ),
            ),
            'validators'  => array(
                new StringLength(array(
                    'min'          => '6',
                    'max'          => '20',
                )),
            ),
        ));
    }
}
