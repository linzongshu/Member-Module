<?php
namespace Module\account\Form;

use Pi;
use Pi\Form\Form as BaseForm;

class LoginForm extends BaseForm
{
    public function init()
    {
        $this->add(array(
            'name'          => 'username',
            'attributes'    => array(
                'type'          => 'text',
                'value'         => 'root',
            ),
            'options'       => array(
                'label'         => __('Username'),
            ),
        ));

        $this->add(array(
            'name'          => 'password',
            'attributes'    => array(
                'type'          => 'password',                
            ),
            'options' => array(
                'label'         => __('Password'),
            ),
        ));
        
        $this->add(array(
            'name'          => 'captcha',
            'type'          => 'captcha',
            'options'       => array(
                'label'         => __('Input following letters '),
            ),
        ));

        $this->add(array(
            'name'          => 'submit',
            'attributes'    => array(
                'type'          => 'submit',
                'value'         => 'Login',
            ),
        ));
    }
}
