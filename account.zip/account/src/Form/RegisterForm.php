<?php
namespace Module\Account\Form;

use Pi;
use Pi\Form\Form as BaseForm;

class RegisterForm extends BaseForm
{
    public function init()
    {
        $this->add(array(
            'name'          => 'username',
            'attributes'    => array(
                'type'          => 'text',
                'value'         => 'root',
            ),
            'options'       => array(
                'label'         => __('Username'),
            ),
        ));

        $this->add(array(
            'name'          => 'password',
            'attributes'    => array(
                'type'          => 'password',
            ),
            'options'       => array(
                'label'         => __('Password'),
            ),
        ));

        $this->add(array(
            'name'          => 'gender',
            'attributes'    => array(
                'value'         => 'm',
                'options'       => array(
                    'm'         => __('Male'),
                    'f'         => __('Female'),
                ),
            ),
            'options'       => array(
                'label'         => __('Gender'),
            ),
            'type'          => 'radio',
        ));

        $this->add(array(
            'name'          => 'upload',
            'attributes'    => array(
                'type'          => 'file',
            ),
            'options'       => array(
                'label'         => __('Upload'),
            ),
        ));

        $this->add(array(
            'name'          => 'country',
            'attributes'    => array(
                'type'      => 'select',
                'value'     => 'CHN',
                'options'   => array(
                    'CHN'       => __('China'),
                    'USA'       => __('United State'),
                ),
            ),
            'options'       => array(
                'label'         => __('Your country'),
            ),
        ));
        
        $this->add(array(
            'name'          => 'email',
            'attributes'    => array(
                'type'          => 'text',
            ),
            'options'       => array(
                'label'         => __('Email'),
            ),
        ));

        $this->add(array(
            'name'          => 'message',
            'attributes'    => array(
                'type'          => 'textarea',
                'cols'          => '50',
                'rows'          => '3',
            ),
            'options'       => array(
                'label'         => __('Introduction'),
            ),
        ));
        
        $this->add(array(
            'name'          => 'captcha',
            'type'          => 'captcha',
        ));

        $this->add(array(
            'name'          => 'submit',
            'attributes'    => array(
                'type'          => 'submit',
                'value'         => __('Register'),
            ),
        ));
    }
}
