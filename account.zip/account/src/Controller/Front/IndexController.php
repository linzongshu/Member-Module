<?php
namespace Module\Account\Controller\Front;

use Pi\Mvc\Controller\ActionController;
use Module\Account\Form\LoginForm;
use Module\Account\Form\LoginFilter;
use Zend\Authentication\Adapter\DbTable;
use Zend\Authentication\AuthenticationService;
use Pi;

class IndexController extends ActionController
{
    protected $auth = null;
    
    public function indexAction()
    {
        $auth = $this->getAuthenticate();
        if($auth->hasIdentity()) {
            $identity = $auth->getIdentity();
            $this->view()->setTemplate('login-success');
            $this->view()->assign('info', array('username' => $identity));
            return;
        }
    
        $form = $this->getForm();
        $this->renderForm($form);
    }

    protected function renderForm($form)
    {
        $this->view()->setTemplate('login');
        $this->view()->assign('title', __('Please login'));
        $this->view()->assign('form', $form);
    }

    protected function getForm()
    {
        $form = new loginForm('login');
        $form->setAttribute('action', $this->url('', array('action' => 'process')));

        return $form;
    }
    
    public function processAction()
    {
        if(!$this->request->isPost())
            return $this->redirect()->toRoute('', array('action' => 'index'));

        $post = $this->request->getPost();
        $form = $this->getForm();
        $form->setData($post);
        $form->setInputFilter(new LoginFilter);
        if(!$form->isValid()) {
            $this->view()->assign('error', __('Invalid input, please try again.'));
            $this->renderForm($form);   
            return;
        }
        $values = $form->getData();
        
        if(!$this->authenticate($values['username'], $values['password'])) {
            $this->view()->assign('error', __('Invalid credentials provided, please try again.'));
            $this->renderForm($form);
            return;
        }

        $this->view()->setTemplate('login-success');
        $this->view()->assign('info', $values);
    }
    
    public function authenticate($identity, $credential)
    {
        $model   = $this->getModel('userinfo');
        $table   = $model->getTable();
        $adapter = $model->getAdapter();
        $authAdapter = new DbTable($adapter, $table, 'username', 'password');
        $authAdapter->setIdentity($identity)->setCredential($credential);

        $auth   = $this->getAuthenticate();
        $result = $auth->authenticate($authAdapter);
        if(!$result->isValid()) {
            return false;
        }

        return true;
    }

    public function getAuthenticate()
    {
        if(null === $this->auth) {
            $this->auth = new AuthenticationService();
        }
        return $this->auth;
    }
    
    public function logoutAction()
    {
        $auth = $this->getAuthenticate();
        $auth->clearIdentity();

        $this->view()->setTemplate('logout-success');
        $this->view()->assign('logout', true);
    }
}
