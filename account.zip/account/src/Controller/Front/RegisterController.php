<?php
namespace Module\Account\Controller\Front;

use Pi\Mvc\Controller\ActionController;
use Module\Account\Form\RegisterForm;
use Module\Account\Form\RegisterFilter;
use Pi;

class RegisterController extends ActionController
{
    protected $adapter = null;
    
    public function indexAction()
    {	
        $form = $this->getForm();
        $this->renderForm($form);
    }

    protected function renderForm($form)
    {
        $this->view()->setTemplate('register');
        $this->view()->assign('title', __('Please register your information'));
        $this->view()->assign('form', $form);
    }

    public function getForm()
    {
        $form = new RegisterForm('register');
        $form->setAttribute('action', $this->url('', array('action' => 'process')));
        $form->setAttribute('enctype', 'multipart/form-data');

        return $form;
    }
    
    public function uploadValidator()
    {
        $destination = Pi::path('upload');
        
        $adapter = $this->getAdapter();
        $adapter->setDestination($destination);
        $adapter->addValidator('Count', false, 1);
        $adapter->addValidator('Size', false, 204800);
        $adapter->addValidator('Extension', false, 'jpg,png,gif');
        
        $messages = null;
        if(!$adapter->receive()){
            $message_list = $adapter->getMessages();
            foreach($message_list as $tmp){
                $messages .= $tmp . "<br/>";
            }
        }

        return $messages;
    }
    
    public function processAction()
    {
        if(!$this->request->isPost())
            return $this->redirect()->toRoute('', array('action' => 'index'));
        
        $post = $this->request->getPost();
        $form = $this->getForm();

        $form->setData($post);
        $form->setInputFilter(new RegisterFilter);
        $file = $this->request->getFiles()->upload;
        if ($file['size']) {
            $messages = $this->uploadValidator();
        }
        if(!$form->isValid() || $messages !== null) {
            $this->view()->assign('error', __('Invalid input, please try again.'));
            $this->view()->assign('messages', $messages);
            $this->renderForm($form);   
            return;
        }
        $values    = $form->getData();
        $adapter   = $this->getAdapter();
        $values['upload'] = Pi::url('upload') . '/' . basename($adapter->getFileName());

        if(!$this->checkUsername($values['username'])) {
            $this->view()->assign('error', __('Username has been register yet, please try again.'));
            $this->renderForm($form);
            return; 
        }
        
        if(!$this->writeIntoDb($values)) {
            $this->view()->assign('error', __('The account is not created in database, please try again.'));
            $this->renderForm($form);
            return;
        }
        
        $this->view()->setTemplate('register-success');
        $this->view()->assign('info', $values);
    }
    
    public function getAdapter()
    {
        if(null === $this->adapter)
            $this->adapter = new \Zend\File\Transfer\Adapter\Http();
        
        return $this->adapter;
    }
    
    public function writeIntoDb(array $value)
    {
        $data = array(
            'username'       => $value['username'],
            'password'       => $value['password'],
            'gender'         => $value['gender'],
            'email'          => $value['email'],
            'country'        => $value['country'],
            'message'        => $value['message'],
            'photo'          => $value['upload'],
        );

        $row = $this->getModel('userinfo')->createRow($data);
        $row->save();
        if(!$row->id) {
            return false;
        }
        
        return true;
    }
    
    public function checkUsername($username)
    {
        $model = $this->getModel('userinfo');
        // Alternative
        $model = Pi::model('account/userinfo');
        $row   = $model->find($username, 'username');
        if($row->id) {
            return false;
        }
        
        return true;
    }
}
