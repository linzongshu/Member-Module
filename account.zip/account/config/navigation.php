<?php
return array(
    'front'   => array(
        'pagea'     => array(
            'label'         => __('User Login'),
            'route'         => 'default',
            'controller'    => 'index',
            'action'        => 'index',
        ),
        'pageb'      => array(
            'label'         => __('User Registration'),
            'route'         => 'default',
            'controller'    => 'register',
            'action'        => 'index',
        ),
    ),
);
