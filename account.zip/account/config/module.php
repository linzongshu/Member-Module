<?php
return array(
    'meta'         => array(
        'title'         => __('Account Demo'),
        'description'   => __('Examples and tests for developers.'),
        'version'       => '1.0.2-beta.1',
        'license'       => 'New BSD',
        'logo'          => 'image/logo.png',
    ),
    'author'        => array(
        'name'          => 'Zongshu Lin',
        'email'         => 'lin40553024@163.com',
        'website'       => 'https://github.com/pi-engine/pi',
        'credits'       => 'Zend Framework Team; Pi Engine Team.'
    ),
    'maintenance'   => array(
        'resource'      => array(
            'database'      => array(
                'sqlfile'   => 'sql/mysql.sql',
                'schema'    => array(
                    'userinfo'    => 'table',
                ),
            ),
            'navigation'    => 'navigation.php',
        ),
    ),
);
